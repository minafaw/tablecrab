"""win32 implementation
"""
